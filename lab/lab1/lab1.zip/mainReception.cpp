#include "swimmingpool.h"
#include "gym.h"
#include "handbook.h"
#include <iostream>

using namespace std;

int main()
{
    cout << endl;
    cout << "I am a freshman of UST. Could you tell the locations of \"";
    Gym gym;
    cout << "\" and \"";
    Swimmingpool swimmingpool;
    cout << "\"." << endl << endl;
    cout << "Welcome Back!" << endl;
    cout << "You could refer to ";
    Handbook handbook;
    cout << endl << " ";
}
