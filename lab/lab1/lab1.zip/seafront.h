#ifndef seafront_H
#define seafront_H

class Seafront
{
public:
    Seafront();
};

#endif