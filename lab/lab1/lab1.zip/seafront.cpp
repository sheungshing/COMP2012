#include "seafront.h"
#include <iostream>
using namespace std;

Seafront::Seafront()
{
    cout << "seafront";
}
