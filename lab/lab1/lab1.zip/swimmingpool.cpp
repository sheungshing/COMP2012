#include "swimmingpool.h"
#include <iostream>
using namespace std;

Swimmingpool::Swimmingpool()
{
    cout << "swimming pool";
}
