#include "gym.h"
#include "swimmingpool.h"
#include "seafront.h"

class Handbook
{
public:
    Handbook();

};
