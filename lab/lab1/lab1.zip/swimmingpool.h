#ifndef swimmingpool_H
#define swimmingpool_H

class Swimmingpool
{
public:
    Swimmingpool();
};

#endif