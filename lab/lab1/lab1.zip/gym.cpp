#include "gym.h"
#include <iostream>
using namespace std;

Gym::Gym()
{
    cout << "gym";
}
