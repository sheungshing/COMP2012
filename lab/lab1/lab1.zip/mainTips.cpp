#include "gym.h"
#include "seafront.h"
#include <iostream>
using namespace std;

int main()
{
    cout << endl;
    cout << "Tips!!!" << endl << "The ";
    Gym gym;
    cout << " on the ";
    Seafront seafront;
    cout << " has not only good equipment but also beautiful natural scenery!" << endl << " ";
}
