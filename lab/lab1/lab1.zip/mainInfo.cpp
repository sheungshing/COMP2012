#include "gym.h"
#include "swimmingpool.h"
#include "seafront.h"

#include <iostream>
using namespace std;

int main()
{
    cout << endl;
    cout << "On the ";
    Seafront seafront;
    cout << ", there is a ";
    Gym gym;
    cout << " and an outdoor ";
    Swimmingpool swimmingpool;
    cout << "." << endl << " ";
}
