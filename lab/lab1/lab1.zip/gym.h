#ifndef gym_H
#define gym_H

class Gym
{
public:
    Gym();
};

#endif