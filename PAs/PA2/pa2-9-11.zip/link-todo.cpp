#include "link.h"

//// TODO: complete the member function defintions of LinkImpl and LinkProxy

//construtor for LinkImpl:
    LinkImpl::LinkImpl(LinkType link_type, LinkProperties properties):Link(link_type),properties_(properties){}
//Member functions: 
    // Returns true if the link has been built.
    bool LinkImpl::IsBuilt() const{
        if(adj_!=nullptr){
            return true;
        }
        return false;
    }
    // Returns true if over-building the provided `link` is successful.
    bool LinkImpl::Build(Link* link){
        if(CanOverbuild(link)){
            link->BeOverbuilt(this);
            set_adjacency(link->adjacency());
        
            return true;
        }
        return false;
    }
    // Returns true if it is possible to overbuild `link`.  
    bool LinkImpl::CanOverbuild(Link* link) const{
        if(link->IsBuilt()){
            return false;
        }
        return true;
        
    }
    // Returns the VP, which is the sum of "VP for adjacent links" from adjacent industries.
    int LinkImpl::vp() const{
        return this->adj_->vp_for_link();
    
    }
    // Returns the player associated to this link.
    Player* LinkImpl::player()const{
        return this->player_;
    }
    std::string LinkImpl::player_name() const{
        return this->player_->name();
    }
    // Associates a player to this link.
    void LinkImpl::set_player(Player* player){
       // delete this->player_;
        this->player_ = player;
    }

    LinkProperties LinkImpl::properties() const{
        
        return properties_;
        
    }
    void LinkImpl::set_observer(LinkObserver* observer){
        static_cast<void>(observer);
    }
    
    // Sets the observer for this link.
   

    //construtor for LinkProxy：
    LinkProxy::LinkProxy(LinkType link_type, Adjacency* adj):Link(link_type,adj){}

    //Member functions:
    bool LinkProxy::IsBuilt() const{
        // if(adjacency() !=nullptr){
        //     return true;
        // }
        // return false;
        return (impl_ != nullptr && (impl_->IsBuilt()));
    }
    bool LinkProxy::Build(Link* link){
        //  if(CanOverbuild(link)){
        //     link->BeOverbuilt(this);
        //     set_adjacency(link->adjacency());
        //     return true;
        // }
        // return false;
        static_cast<void>(link);
        return false;
     }
    bool LinkProxy::CanOverbuild(Link* link) const{
        // if(link->IsBuilt()){
        //     return false;
        // }
        // return true;

        static_cast<void>(link);
        return false;
    }
    // Reacts to being over-built by another `link`. Should be used in `Build()` only.
    // Note: this can be made protected if we set LinkProxy as a friend of the Link class.
     // But doing this might confuse you and we decide not to do so.
    void LinkProxy::BeOverbuilt(Link* link){
        //set_adjacency(link->adjacency());
            
        if(impl_!= nullptr){
            impl_->BeOverbuilt(link);
        }
        impl_ = static_cast<LinkImpl*>(link);
        link->set_observer(this->observer_);
        link->set_adjacency(this->adj_);
        
        if(observer_){
            observer_->UpdateLink(this);
        }
    }
    int LinkProxy::vp() const{
        return (impl_ == nullptr)? 0 : impl_->vp();
    }

    // Returns the properties (a data class) of the link.
    LinkProperties LinkProxy::properties() const{
        if(impl_ != nullptr){
        return impl_->properties();
        }
        return{};
    }
    // Returns the player associated to this link.
    Player* LinkProxy::player() const{
        return (impl_ == nullptr)? nullptr : impl_->player();
    }
    std::string LinkProxy::player_name() const{
        if (impl_ != nullptr) {
        return impl_->player_name();
        }
        return kEmptyPlayerName;
    }
    void LinkProxy::set_player(Player* player){
       static_cast<void>(player);
    }
    void LinkProxy::set_observer(LinkObserver* observer){
       // delete observer_;
        observer_ = observer;
    }


    


    




//// TODO ends
