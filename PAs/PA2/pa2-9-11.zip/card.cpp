#include "card.h"

#include "util-common.h"

//// TODO: Complete the member function defintion of the cardd classes

    Card::Card(const std::string& name):name_(name){}
    Card::~Card(){
        
    }

    // Returns true if the card can be realized as a "Wild Card".

    bool Card::IsWildCard() const{
        if(name_ == "Wild Location" || name_ == "Wild Industry" ){
            return true;
        }
        return false;
    }

    // Returns true if the card's specification allows us to overbuild
    // the industry `to_be_overbuilt`, i.e., assume we are going to build
    // a valid industry on it, does the card permit us to do so?

    // bool Card::CanIndustryBeOverbuilt(const PlayerNetwork* network,const Industry* to_be_overbuilt) const{

    //                           }

    // Returns the card type.
    //LocationCard
    LocationCard:: LocationCard(Location* location):Card(location->name()),location_(location){}

    CardType LocationCard::card_type()const{
        return CardType::kLocationCard;
    }

    std::string LocationCard::name() const{
        return location_->name();
    }

    bool LocationCard::CanIndustryBeOverbuilt(const PlayerNetwork* network,const Industry* to_be_overbuilt) const{
       if(location_->name() == to_be_overbuilt->location()->name()){
           return true;
       }
       return false;

    }

    //WildLocationCard
    WildLocationCard::WildLocationCard():Card("Wild Location"){}

    CardType WildLocationCard::card_type() const{
        return CardType::kWildLocationCard;
    }

    std::string WildLocationCard::name() const{
        return "Wild Location";
    }

    bool WildLocationCard::CanIndustryBeOverbuilt(const PlayerNetwork* network,const Industry* to_be_overbuilt) const{

        return true;
    }

    //IndustryCard
    IndustryCard::IndustryCard(IndustryType industry_type):Card(ToString(industry_type)),industry_type_(industry_type){}

    CardType IndustryCard::card_type() const{
        return CardType::kIndustryCard;
    }

    std::string IndustryCard::name() const{
        return ToString(industry_type_);
    }

    bool IndustryCard::CanIndustryBeOverbuilt(const PlayerNetwork* network,const Industry* to_be_overbuilt) const{
        if((network->IsCovering(to_be_overbuilt->location())
        ||network->num_built_industries() +network->num_built_links() == 0)
        && to_be_overbuilt->industry_type()== this->industry_type_ ){
            return true;
        }
        return false;
    }

    //WildIndustryCard
    WildIndustryCard::WildIndustryCard():Card("Wild Industry"){}
    CardType WildIndustryCard::card_type() const{
        return CardType::kWildIndustryCard;
    }

    std::string WildIndustryCard::name() const{
        return "Wild Industry";
    }

    bool WildIndustryCard::CanIndustryBeOverbuilt(const PlayerNetwork* network,const Industry* to_be_overbuilt) const{
        if(network->IsCovering(to_be_overbuilt->location())){
            return true;
        }
        return false;
    }

//// TODO ends
