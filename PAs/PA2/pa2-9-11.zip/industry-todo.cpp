#include "industry.h"

#include "player.h"

//// TODO: Complete primary and secondary industries

    //Constructor for PrimaryIndustry:
    PrimaryIndustry::PrimaryIndustry(IndustryType industry_type, IndustryProperties properties,
                  ResourceType resource_type):IndustryImpl(industry_type, properties,resource_type){}
       
//Member functions:
  // This can overbuild the `other` industry if this is more technologically advanced,
  // and they are of the same industry type. Usually the owner of this industry must
  // also own the industry that he overbuilds on. However, if the game board has
  // exhausted all the resources, or the `other` industry is not yet built
  // (i.e. representing an empty slot), any player can overbuild the given industry
  // and is still subject to the tech level requirement.
  // Hint: As we alway overbuild through an industry proxy, an an industry proxy always
  //       has a resource observer attached, we can assume `other` is assoicated
  //       to a valid resource observer.
    bool PrimaryIndustry::CanOverbuild(Industry* other) const{
        
        PrimaryIndustry* temp=static_cast<PrimaryIndustry*>(other);
        bool eh=temp->resource_observer_->HasResource(temp->resource_type());

            if((this->properties().tech_level > other->properties().tech_level 
                && this->industry_type()==other->industry_type())
                &&(this->player_name()==other->player_name()
                ||eh == false
                ||other->IsBuilt()==false)) return true;
            return false;

            

        }
    // Returns true if all of its resource units are consumed.
    bool PrimaryIndustry::IsEligibleForVp() const{
            if(this->IsBuilt()==true && this->available_units_==0)
                return true;
            return false;
        }
    // Provides the given nubmer of resource units if possible.
    // Notifies the resource and industry observes of the change.
    bool PrimaryIndustry::ProvideResources(int units){
        if(available_units_ >= units){
            available_units_ -= units;
            if(available_units_ == 0){
                player_->IncreaseExp(properties_.output_units);
            }
            resource_observer_->UpdateResourceCount(this->resource_type(),available_units_);
            industry_observer_->UpdateIndustry(this);
            return true;
        }
        return false;
    }
    // Returns the inventory of the industry.
    int PrimaryIndustry::available_units() const{
        return available_units_;
    }
    // Sets the resource observer of the industry.
    void PrimaryIndustry::set_resource_observer(ResourceObserver* rsrc_observer){
        resource_observer_ = rsrc_observer;
    }
    // Produces the number of output units specified by its properties,
    // and notifies the resource and industry observers of the change.
    void PrimaryIndustry::ProduceResources(){
        available_units_ += properties_.output_units;
        resource_observer_->UpdateResourceCount(this->resource_type(),available_units_);
        industry_observer_->UpdateIndustry(this);
    }
    // Removes all the resource units available and notifies the
    // resource and industry observers of the change.
    void PrimaryIndustry::RemoveResources(){
        available_units_ = 0;
       // player_->IncreaseExp(properties().exp_increase);
        resource_observer_->UpdateResourceCount(this->resource_type(),available_units_);
        industry_observer_->UpdateIndustry(this);
    }

//------------------------------------------------------------------------------------------
    //construtor for SecondaryIndustry:
    SecondaryIndustry::SecondaryIndustry(IndustryType industry_type, IndustryProperties properties)
        :IndustryImpl(industry_type,properties){}
    
    //Member functions:
    // This is similar to the function you solved for PrimaryIndustry.
    // Just that we do not allow other players who do not own the `other`
    // industry to build on it, if it is already built.
    bool SecondaryIndustry::CanOverbuild(Industry* other) const{
        if(this->properties().tech_level > other->properties().tech_level
            &&this->industry_type()==other->industry_type()
            &&(this->player_name()==other->player_name()
            ||other->IsBuilt()==false)){
            return true;
        }
        return false;
    }
    // Returns true if the industry is sold.
    bool SecondaryIndustry::IsEligibleForVp() const{
        if(sold_ == true && this->IsBuilt()==true)
            return true;
        return false;
    }
    // Sells the industry, and increase the player's EXP by a number
    // specified in the industry's properties.
    bool SecondaryIndustry::Sell(){
        if(!sold_){
        sold_ = true;
        player_->IncreaseExp(properties().exp_increase);
        return true;
        } 
        return false;
    }
    // Returns true if the industry is already sold.
    bool SecondaryIndustry::sold() const{
        if(sold_ == true)
            return true;
        return false;
    }
    // Ignores the resource observer as a secondary industry does not produce
    // consumerable resources for players.
    void SecondaryIndustry::set_resource_observer(ResourceObserver* rsrc_observer){
       // resource_observer_ = rsrc_observer;
       static_cast<void>(rsrc_observer);
        
    }



//// TODO ends
